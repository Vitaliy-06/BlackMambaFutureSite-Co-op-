﻿using BlackMambaSite.Models;
using Microsoft.AspNetCore.Hosting;
using System.Text.Json;

namespace BlackMambaSite.Services
{
    public class JsonFilePostService
    {
        public IWebHostEnvironment WebHostEnvironment { get; }
        public JsonFilePostService(IWebHostEnvironment webHostEnvironment) 
        {
            WebHostEnvironment = webHostEnvironment;
        }

        private string JsonFileName
        {
            get
            {
                return Path.Combine(WebHostEnvironment.WebRootPath, "data", "posts.json");
            }
        }
        
        public IEnumerable<Post> GetPosts()
        {
            using(var jsonFileReader = File.OpenText(JsonFileName))
            {
                return JsonSerializer.Deserialize<Post[]>(jsonFileReader.ReadToEnd(),
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
            }
        }
    }
}
