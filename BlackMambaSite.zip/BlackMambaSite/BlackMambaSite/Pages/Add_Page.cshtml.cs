using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlackMambaSite.Pages
{
    public class Add_PageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
