using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlackMambaSite.Pages
{
    public class About_PageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
