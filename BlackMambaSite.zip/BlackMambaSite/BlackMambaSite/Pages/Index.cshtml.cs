﻿using BlackMambaSite.Models;
using BlackMambaSite.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlackMambaSite.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public JsonFilePostService PostService { get; set; }
        public IEnumerable<Post> Posts { get; private set; }

        public IndexModel(ILogger<IndexModel> logger, JsonFilePostService jsonFilePostService)
        {
            PostService = jsonFilePostService;
            _logger = logger;
        }

        public void OnGet()
        {
            Posts = PostService.GetPosts();
        }
    }
}